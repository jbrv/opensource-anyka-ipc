#ifndef	DO_DEPS_ONLY

#include <generated/generic-asm-offsets.h>
/* #include <generated/asm-offsets.h> */

#endif
