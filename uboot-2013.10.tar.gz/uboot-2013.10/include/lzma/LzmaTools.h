/*
 * Fake include for LzmaTools.h
 *
 * Copyright (C) 2007-2009 Industrie Dial Face S.p.A.
 * Luigi 'Comio' Mantellini (luigi.mantellini@idf-hit.com)
 *
 * SPDX-License-Identifier:	GPL-2.0+ 
 */

#ifndef __LZMATOOLS_H__FAKE__
#define __LZMATOOLS_H__FAKE__

#include "../../lib/lzma/LzmaTools.h"

#endif
